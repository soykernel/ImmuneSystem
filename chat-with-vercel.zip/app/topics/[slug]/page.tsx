import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import Link from 'next/link'
import { topics, getTopic } from '@/lib/content'
import { ContentRenderer } from '@/components/content-renderer'
import { BackLink } from '@/components/back-link'

export function generateStaticParams() {
  return topics.map((t) => ({ slug: t.slug }))
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const { slug } = await params
  const topic = getTopic(slug)
  if (!topic) return { title: 'Not found' }
  return {
    title: `${topic.title} · The Immune System`,
    description: topic.summary,
  }
}

export default async function TopicPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const topic = getTopic(slug)
  if (!topic) notFound()

  return (
    <main className="mx-auto w-full max-w-3xl px-4 py-10">
      <BackLink />

      <header className="mt-6 rounded-2xl bg-magenta p-8 text-cream shadow-lg">
        <h1 className="font-display text-3xl leading-tight text-balance sm:text-4xl">{topic.title}</h1>
        <p className="mt-3 text-sm opacity-90">{topic.subtitle}</p>
        <p className="mt-4 border-t border-cream/30 pt-4 text-xs uppercase tracking-wide opacity-80">
          {topic.author} · {topic.date}
        </p>
      </header>

      {topic.status === 'in-progress' ? (
        <section className="mt-8 rounded-2xl bg-card p-8 text-center shadow-lg">
          <h2 className="text-xl font-bold text-cream text-balance">
            We are currently working hard on this section and will be launching soon.
          </h2>
          <p className="mt-3 text-cream/80">Please stay tuned for updates!</p>
          <a
            href="https://www.linkedin.com/in/wenying-zhao/"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-block rounded-full bg-coral px-6 py-2 font-semibold text-cream transition-transform hover:-translate-y-0.5"
          >
            Follow me on LinkedIn :D
          </a>
        </section>
      ) : (
        <>
          <p className="mt-8 text-base leading-relaxed text-cream/90 text-pretty">{topic.summary}</p>

          <div className="mt-8 space-y-10">
            {topic.sections?.map((section, i) => (
              <section key={i} className="rounded-2xl bg-card p-6 shadow-lg sm:p-8">
                <h2 className="mb-5 border-b border-cream/15 pb-3 font-display text-2xl text-cream">
                  {section.heading}
                </h2>
                <ContentRenderer blocks={section.blocks} />
              </section>
            ))}
          </div>

          {topic.sources && topic.sources.length > 0 && (
            <section className="mt-8 rounded-2xl border border-cream/15 bg-card/40 p-6">
              <h2 className="mb-3 text-sm font-bold uppercase tracking-wide text-cream/70">Sources &amp; References</h2>
              <ul className="ml-5 list-disc space-y-1 text-xs text-cream/60">
                {topic.sources.map((s, i) => (
                  <li key={i} className="break-words">
                    {s}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </>
      )}

      <div className="mt-10 flex justify-center">
        <Link
          href="/"
          className="rounded-full bg-grape px-6 py-2 font-semibold text-cream transition-transform hover:-translate-y-0.5"
        >
          Back to all topics
        </Link>
      </div>
    </main>
  )
}
