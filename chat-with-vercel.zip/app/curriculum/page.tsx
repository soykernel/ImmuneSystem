import type { Metadata } from 'next'
import { BackLink } from '@/components/back-link'
import { Download } from 'lucide-react'

export const metadata: Metadata = {
  title: 'The H3 Biology Curriculum · The Immune System',
  description: 'H3 Biology 2025 notes, viewed inside the site.',
}

export default function CurriculumPage() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-5xl flex-col px-4 py-10">
      <BackLink />

      <header className="mt-6 rounded-2xl bg-magenta p-8 text-cream shadow-lg">
        <h1 className="font-display text-3xl leading-tight text-balance sm:text-4xl">The H3 Biology Curriculum</h1>
        <p className="mt-3 text-sm leading-relaxed opacity-90 text-pretty">
          H3 Biology is an advanced, university-level GCE A-Level subject in Singapore designed to stretch high-ability
          students. Building on H2 Biology, it focuses on self-directed learning and real-world scientific applications.
        </p>
        <p className="mt-4 border-t border-cream/30 pt-4 text-xs uppercase tracking-wide opacity-80">
          Source: Library — grail.moe, &ldquo;H3 Biology 2025 Notes&rdquo; by zc000, 2025
        </p>
      </header>

      <section className="mt-6 flex-1 rounded-2xl bg-card p-3 shadow-lg sm:p-4">
        <div className="mb-3 flex items-center justify-between px-2">
          <h2 className="text-sm font-semibold text-cream/80">Document viewer</h2>
          <a
            href="/documents/h3_bio.pdf"
            download
            className="inline-flex items-center gap-2 rounded-full bg-coral px-4 py-1.5 text-sm font-semibold text-cream transition-transform hover:-translate-y-0.5"
          >
            <Download className="size-4" aria-hidden="true" />
            Download
          </a>
        </div>
        <object
          data="/documents/h3_bio.pdf"
          type="application/pdf"
          className="h-[75vh] w-full rounded-xl bg-cream"
          aria-label="H3 Biology 2025 Notes"
        >
          <div className="flex h-full flex-col items-center justify-center gap-3 p-8 text-center">
            <p className="text-cream/80">
              Your browser can&apos;t display the embedded PDF here.
            </p>
            <a
              href="/documents/h3_bio.pdf"
              download
              className="rounded-full bg-coral px-6 py-2 font-semibold text-cream"
            >
              Download the notes
            </a>
          </div>
        </object>
      </section>
    </main>
  )
}
