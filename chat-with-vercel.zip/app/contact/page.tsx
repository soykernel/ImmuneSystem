import type { Metadata } from 'next'
import { BackLink } from '@/components/back-link'
import { Mail, Phone, School, Award } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Contact · The Immune System',
  description: 'Get in touch with Zhao Wenying.',
}

const extracurriculars = [
  'Tubist of Concert Band',
  'Musician in Chili Crab Ensemble (ICS)',
  'Biolympian of SJBO Training Team',
  'EXCO member of HCNY Astro',
  'Class Committee Member (2025–2026)',
]

export default function ContactPage() {
  return (
    <main className="mx-auto w-full max-w-2xl px-4 py-10">
      <BackLink />

      <header className="mt-6 rounded-2xl bg-magenta p-8 text-cream shadow-lg">
        <h1 className="font-display text-3xl sm:text-4xl">Zhao Wenying</h1>
        <p className="mt-2 text-sm opacity-90">Nanyang Girls&apos; High School · Class 2-02 B28</p>
      </header>

      <section className="mt-6 space-y-3 rounded-2xl bg-card p-6 shadow-lg sm:p-8">
        <a
          href="mailto:fengjixin531@gmail.com"
          className="flex items-center gap-3 rounded-xl p-3 text-cream transition-colors hover:bg-grape/40"
        >
          <Mail className="size-5 shrink-0 text-coral" aria-hidden="true" />
          fengjixin531@gmail.com
        </a>
        <a
          href="tel:+6580793858"
          className="flex items-center gap-3 rounded-xl p-3 text-cream transition-colors hover:bg-grape/40"
        >
          <Phone className="size-5 shrink-0 text-coral" aria-hidden="true" />
          +65 8079 3858
        </a>
        <div className="flex items-center gap-3 p-3 text-cream">
          <School className="size-5 shrink-0 text-coral" aria-hidden="true" />
          Nanyang Girls&apos; High School, Class 2-02 B28
        </div>
      </section>

      <section className="mt-6 rounded-2xl bg-card p-6 shadow-lg sm:p-8">
        <h2 className="mb-4 font-display text-xl text-cream">Extracurriculars</h2>
        <ul className="ml-5 list-decimal space-y-2 text-cream/90 marker:font-semibold marker:text-coral">
          {extracurriculars.map((item) => (
            <li key={item} className="leading-relaxed">
              {item}
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-6 rounded-2xl border-l-4 border-coral bg-card/60 p-6">
        <div className="flex items-start gap-3">
          <Award className="mt-0.5 size-5 shrink-0 text-coral" aria-hidden="true" />
          <div className="space-y-2 text-cream/85">
            <p className="font-semibold">
              Come fight me — I have a Diploma in Diet Planning and Japanese Language (from Alison lmao) and a
              Certificate in Food Safety and Hygiene.
            </p>
            <p className="text-sm">
              If you have time, come friend me on Arcaea! <strong className="text-cream">UID: 532 330 035</strong>
            </p>
          </div>
        </div>
      </section>

      <div className="mt-8 flex justify-center">
        <a
          href="https://www.linkedin.com/in/wenying-zhao/"
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-full bg-grape px-6 py-2 font-semibold text-cream transition-transform hover:-translate-y-0.5"
        >
          My LinkedIn
        </a>
      </div>
    </main>
  )
}
