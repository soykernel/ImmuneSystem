import { DashboardTile } from '@/components/dashboard-tile'

export default function HomePage() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col justify-center px-4 py-10">
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        {/* Title / intro tile */}
        <div className="group relative flex flex-col items-center justify-center overflow-hidden rounded-2xl bg-magenta p-8 text-center text-cream shadow-lg sm:col-span-2">
          <div className="transition-opacity duration-200 group-hover:opacity-0">
            <h1 className="font-display text-4xl leading-tight sm:text-5xl">The Immune System</h1>
          </div>
          <p className="pointer-events-none absolute inset-0 flex items-center justify-center px-8 text-sm leading-relaxed opacity-0 transition-opacity duration-200 group-hover:opacity-100 text-pretty">
            This is an incomplete overview of the Immunology topics in A-level Biology, making reference to Janeway&apos;s
            Immunobiology 10th edition. This document is a compilation and synthesis of existing publicly available
            online sources. No primary research, surveys, or original experiments were conducted for this compilation.
            All data and insights are attributed to their respective original sources.
          </p>
          <h2 className="mt-4 border-t border-cream/30 pt-4 text-sm opacity-90 text-pretty">
            Based on H2–H3 Biology and Janeway&apos;s Immunobiology (click on each tile for more information!)
          </h2>
        </div>

        <DashboardTile
          href="/contact"
          accent="grape"
          title="Contact"
          hover="+65 8079 3858 · fengjixin531@gmail.com · Class 2-02, NYGH B28 (click me!)"
        />

        <DashboardTile
          href="/curriculum"
          accent="grape"
          title="The H3 Biology Curriculum"
          hover="H3 Biology is an advanced, university-level GCE A-Level subject in Singapore designed to stretch high-ability students. Building on H2 Biology, it focuses on self-directed learning and real-world scientific applications. (source: Library — grail.moe, H3 Biology 2025 Notes by zc000, 2025)"
        />

        <DashboardTile
          href="/topics/glycosylation"
          accent="coral"
          title="Glycosylation (Protein Modification)"
          hover="Glycoprotein structure, key CD markers across immune cells, and N-linked vs O-linked glycoproteins."
        />

        <DashboardTile
          href="/topics/glycoprotein-half-life"
          accent="coral"
          title="Glycoprotein Half-life (enrichment)"
          hover="How glycan and protein architecture control a glycoprotein's circulatory half-life and clearance."
        />

        <DashboardTile
          href="/topics/vertebrate-immune-cells"
          accent="coral"
          title="Vertebrate Immune Cells"
          hover="Hematopoietic stem cells and the full differentiation pathway of immune cells."
        />

        <DashboardTile
          href="/topics/lines-of-barriers"
          accent="coral"
          title="Lines of Barriers Against Pathogens"
          hover="Avoidance, resistance, and tolerance — the layered defenses against infectious microbes."
        />

        <DashboardTile
          href="/topics/cell-mediated-immunity"
          accent="coral"
          title="Cell-mediated Immunity"
          hover="In progress — launching soon!"
          badge="Soon"
        />

        <DashboardTile
          href="/topics/myeloid-lineage"
          accent="coral"
          title="The Myeloid Lineage"
          hover="In progress — launching soon!"
          badge="Soon"
        />

        <DashboardTile
          href="/topics/lymphoid-lineage"
          accent="coral"
          title="The Lymphoid Lineage"
          hover="In progress — launching soon!"
          badge="Soon"
        />
      </div>

      <footer className="mt-8 text-center text-sm text-cream/60">
        Compiled by Zhao Wenying · Nanyang Girls&apos; High School
      </footer>
    </main>
  )
}
