import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Black_Ops_One, Nunito_Sans } from 'next/font/google'
import './globals.css'

const blackOps = Black_Ops_One({
  subsets: ['latin'],
  weight: '400',
  variable: '--font-display',
  display: 'swap',
})

const nunitoSans = Nunito_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'The Immune System',
  description:
    "An interactive overview of Immunology topics in A-level Biology, referencing Janeway's Immunobiology 10th edition. By Zhao Wenying.",
  generator: 'v0.app',
}

export const viewport: Viewport = {
  themeColor: '#443199',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`bg-background ${blackOps.variable} ${nunitoSans.variable}`}>
      <body className="antialiased font-sans">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
