// Structured immunology content, transcribed from the original source PDFs
// authored by Zhao Wenying. Rendered as in-site web pages instead of raw PDFs.

export type Block =
  | { type: "paragraph"; text: string }
  | { type: "heading"; text: string }
  | { type: "list"; ordered?: boolean; items: ListItem[] }
  | { type: "note"; text: string }
  | { type: "table"; headers: string[]; rows: string[][] }

export type ListItem = {
  text: string
  children?: ListItem[]
}

export type Section = {
  heading: string
  blocks: Block[]
}

export type Topic = {
  slug: string
  title: string
  subtitle: string
  author: string
  date: string
  accent: "magenta" | "purple" | "red"
  status: "published" | "in-progress"
  summary: string
  sections?: Section[]
  sources?: string[]
}

export const topics: Topic[] = [
  {
    slug: "glycosylation",
    title: "Glycosylation",
    subtitle: "Protein Modification — Based on H3 Biology (2025)",
    author: "Zhao Wenying",
    date: "June 16, 2026",
    accent: "red",
    status: "published",
    summary:
      "H3 Biology is an advanced, university-level GCE A-Level subject in Singapore. This section covers glycoprotein structure, CD markers across immune cells, and the difference between N-linked and O-linked glycoproteins.",
    sections: [
      {
        heading: "Glycoproteins",
        blocks: [
          {
            type: "paragraph",
            text: "The structure of a glycoprotein is that of an oligosaccharide covalently bonded with a protein. The process by which this occurs is glycosylation, which typically occurs in the endoplasmic reticulum and Golgi apparatus.",
          },
        ],
      },
      {
        heading: "Key CD Markers in Humans",
        blocks: [
          {
            type: "paragraph",
            text: "Glycoproteins play a major role in bodily cells, especially in the immune system e.g. leukocytes. On leukocytes they function as CD markers (Clusters of Differentiation markers), CD45 being a universal marker for all white blood cells. A positive indicator for CD45 confirms a cell's identity as a leukocyte.",
          },
          {
            type: "list",
            ordered: true,
            items: [
              {
                text: "Lymphocytes (Agranulocytes)",
                children: [
                  {
                    text: "T cells",
                    children: [
                      { text: "CD3 — Universal biomarker for T cells, binds with the TCR complex for intracellular signalling." },
                      { text: "CD4 — Helper T cells express CD4+, a coreceptor for antigen recognition." },
                      { text: "CD8 — Cytotoxic T cells express CD8+, activating the T cell to release destructive enzymes and increasing sensitivity to foreign antigens. The CD3/4/8 count test supports the diagnosis of HIV and AIDS." },
                    ],
                  },
                  {
                    text: "B cells",
                    children: [
                      { text: "CD19 — Important coreceptor on the B-cell surface." },
                      { text: "CD20 — Acts as a calcium-ion channel on the plasma membrane, expressed ONLY from the late pre-B stage until mature B." },
                    ],
                  },
                  {
                    text: "Natural Killer (NK) cells",
                    children: [
                      { text: "CD56 — Homophilic adhesion molecule, binding to cells sharing CD56; expression density defines NK cell sub-populations." },
                    ],
                  },
                ],
              },
              {
                text: "Monocytes (Agranulocytes)",
                children: [
                  { text: "CD14 — Binds to Lipopolysaccharide (LPS, a toxic molecule found on Gram-negative bacteria) and transfers it to a neighbouring receptor, triggering release of inflammatory cytokines." },
                  { text: "CD16 — Used alongside CD14 to split monocytes into functional subgroups (Classical, Intermediate, Non-classical); triggers phagocytosis / release of toxins." },
                ],
              },
              {
                text: "Granulocytes",
                children: [
                  {
                    text: "Neutrophils",
                    children: [
                      { text: "CD16 — Definitive marker for mature neutrophils, triggers phagocytosis after an antibody is detected." },
                      { text: "CD15 — Rolling adhesion, targets inflammation by rolling along the blood vessel wall." },
                    ],
                  },
                  {
                    text: "Eosinophils",
                    children: [
                      { text: "CD193 — Chemotaxis; senses the gradient of eotaxins (secreted by damaged tissues) and physically steers the eosinophil to the site." },
                      { text: "CD49d — Tissue entry; adhesion to tissue to move to the site." },
                    ],
                  },
                  {
                    text: "Basophils",
                    children: [
                      { text: "CD123 — Part of a subunit telling the basophil to maintain life." },
                      { text: "FceR1 (Fc Epsilon Receptor Ia) — Allergic reaction alpha subunit of IgE; when an allergen cross-links with IgE, triggers release of histamine into blood." },
                    ],
                  },
                ],
              },
            ],
          },
          { type: "note", text: "Go to the BD CD Marker Handbook for more information." },
        ],
      },
      {
        heading: "Structure",
        blocks: [
          {
            type: "paragraph",
            text: "Glycoproteins can be categorised by how the sugar chain is linked to the protein, giving rise to two main groups: N-linked and O-linked.",
          },
          {
            type: "paragraph",
            text: "There are 10 possible monosaccharides in glycans which can be linked to a peptide chain:",
          },
          {
            type: "list",
            items: [
              { text: "Glucose (Glc)" },
              { text: "Fucose (Fuc)" },
              { text: "Xylose (Xyl)" },
              { text: "Mannose (Man)" },
              { text: "Galactose (Gal)" },
              { text: "N-acetylglucosamine (GlcNAc)" },
              { text: "Glucuronic acid (GlcA)" },
              { text: "Iduronic acid (IdoA)" },
              { text: "N-acetylgalactosamine (GalNAc)" },
              { text: "Sialic acid — a key dependency in glycoprotein half-life" },
              { text: "5-N-acetylneuraminic acid (Neu5Ac)" },
            ],
          },
          {
            type: "paragraph",
            text: "A glycan chain can be made of 2 to 15 monosaccharide units, which connect to the protein via specific amino side chains.",
          },
          { type: "heading", text: "O-linked Glycoproteins" },
          {
            type: "list",
            items: [
              { text: "Sugars bind to the -OH group of Serine (Ser) or Threonine (Thr) residues via the O-glycosidic bond." },
              { text: "Common in mucins to provide a protective, gel-like barrier in the respiratory and gastrointestinal tracts." },
              { text: "e.g. Mucins, Blood antigens, Collagen." },
            ],
          },
          { type: "heading", text: "N-linked Glycoproteins" },
          {
            type: "list",
            items: [
              { text: "Oligosaccharide attaches to the -NH2 group of Asparagine (Asn) residues." },
              { text: "e.g. Immunoglobulins / Antigens (IgA, IgG, IgM), Receptors, Thyroglobulin." },
            ],
          },
          {
            type: "table",
            headers: ["", "N-linked", "O-linked"],
            rows: [
              ["Site of glycosylation", "Initiated in ER, modified in Golgi", "Strictly occurs in the Golgi apparatus"],
              ["Attachment site", "Asparagine (Asn)", "Serine (Ser) or Threonine (Thr)"],
              ["Chain complexity", "Highly branched, structurally complex", "Shorter, simpler, more linear"],
              ["Primary function", "Protein folding, quality control, cell recognition", "Barrier, lubrication, cell adhesion"],
            ],
          },
          { type: "heading", text: "More about Mucin" },
          {
            type: "paragraph",
            text: "Mucins are around 80% O-linked glycoprotein, and one of the most commonly found O-linked glycoproteins. Mucins rely on these O-linked glycans to function, with carbohydrate chains covalently attached to the hydroxyl group of serine and threonine amino acids.",
          },
        ],
      },
    ],
    sources: [
      "creative-diagnostics.com — Functions of Human CD Markers",
      "Kyventidis, A., Tzimagiorgis, G. & Didangelos, T. (2015). Hippokratia. 19. 344-351.",
      "sciencedirect.com/article/abs/pii/S0008621522000994",
      "researchgate.net — Schematic structure of mucin glycoproteins",
    ],
  },
  {
    slug: "glycoprotein-half-life",
    title: "Glycoprotein Half-life",
    subtitle: "Structural Dynamics and Clearance Mechanics (enrichment)",
    author: "Zhao Wenying",
    date: "April–May 2026",
    accent: "red",
    status: "published",
    summary:
      "The circulatory half-life of a glycoprotein is highly variable and depends on a fine-tuned balance between its protein architecture and its attached glycan structures.",
    sections: [
      {
        heading: "Glycan-Related Factors",
        blocks: [
          {
            type: "paragraph",
            text: "Glycosylation is the process of forming a glycoprotein or glycolipid by attaching a glycan to a lipid or protein. This pathway occurs mainly in the Endoplasmic Reticulum (ER) and the Golgi Apparatus. Key structural features of the glycan modify half-life through specific clearance pathways.",
          },
          { type: "heading", text: "1. Terminal Sialic Acid Content" },
          {
            type: "paragraph",
            text: "This is a primary determinant of a glycoprotein's circulatory half-life. Sialic acid is a negatively charged sugar molecule capping the terminal ends of sugar chains.",
          },
          {
            type: "list",
            items: [
              { text: "Exposed Galactose: If glycans lack sialic acid, underlying galactose residues are exposed. The asialoglycoprotein receptor (ASGPR) on liver hepatocytes recognises exposed galactose as an old or damaged molecule, triggering destruction and a shorter half-life." },
              { text: "Sialic Acid Capping: Sialic acid covers galactose, allowing the molecule to bypass ASGPR recognition. It continues circulating, leading to a longer half-life (e.g. engineered erythropoietin / EPO)." },
            ],
          },
          { type: "heading", text: "2. Glycan Structure and Size" },
          {
            type: "paragraph",
            text: "The specific structural configuration, degree of branching, and overall physical size of the carbohydrate moieties heavily influence solubility, biophysical stability, and baseline exposure to degradation proteases or clearance receptors.",
          },
          { type: "heading", text: "3. Glycosylation Site Location" },
          {
            type: "paragraph",
            text: "The precise positioning (N-linked vs. O-linked) of the glycan on the protein backbone alters its three-dimensional tertiary conformation, steering enzyme accessibility and receptor binding interactions.",
          },
          {
            type: "note",
            text: "Sialylation covers underlying sugars (galactose, mannose) with terminal sialic acid, letting therapeutic proteins evade clearance receptors. Mannose-6-Phosphate residues enable targeting and uptake by cells such as macrophages. Certain non-human glycans (the α-Gal Epitope and Neu5Gc residue) differ from human glycans and can trigger adverse immune responses.",
          },
        ],
      },
      {
        heading: "Protein-Related Factors",
        blocks: [
          {
            type: "paragraph",
            text: "Intrinsic protein properties govern baseline susceptibility to enzymatic degradation and mechanical filtration pathways.",
          },
          {
            type: "list",
            ordered: true,
            items: [
              {
                text: "Amino Acid Sequence and Structure — the underlying peptide code dictates thermodynamic stability and maps target destruction signals:",
                children: [
                  { text: "N-end Rule: if a protein's active sequence exposes amino acids like arginine or leucine at its absolute terminus, it is instantly tagged for destruction within the proteasome." },
                  { text: "Ubiquitination Sites: particular sequence segments attract molecular 'ubiquitin' tags, marking the protein for structural destruction." },
                ],
              },
              { text: "Molecular Weight & Kidney Filtration — glycoproteins under the renal filtration threshold (≈ 40–50 kDa) face rapid clearance via the kidneys. Attached glycans add molecular weight, shielding smaller proteins from physical filtration." },
              { text: "Protein Folding and Conformational Stability — the overall 3D conformation alters resilience against denaturation, physical aggregation, and spontaneous chemical instability (oxidation, hydrolysis)." },
              { text: "Interaction with Secondary Clearance Receptors — beyond liver ASGPR, receptors like the Mannose Receptor (MR) selectively bind exposed high-mannose glycan patterns to facilitate uptake and lysosomal degradation." },
            ],
          },
        ],
      },
      {
        heading: "External and Cellular Factors",
        blocks: [
          {
            type: "list",
            items: [
              {
                text: "Cellular Metabolism and Expression Environment — the host cell line, its enzyme collection, sugar-nucleotide donor availability, and processing residence time in the Golgi affect the ultimate glycosylation blueprint.",
                children: [
                  { text: "Overexpression: forcing cells to over-express glycoproteins in a rush leads to immature, truncated high-mannose glycan profiles that are quickly cleared." },
                ],
              },
              { text: "Physical and Chemical Conditions — conditions during production, purification, storage, and in vivo (pH, temperature fluctuations, protease levels) continuously impact physical stability." },
            ],
          },
          { type: "note", text: "In vivo refers to the natural, complex internal environment of a living, whole organism." },
        ],
      },
    ],
    sources: [
      "Glycosylation Shapes the Efficacy and Safety of Diverse Protein, Gene and Cell Therapies",
    ],
  },
  {
    slug: "vertebrate-immune-cells",
    title: "Vertebrate Immune Cells",
    subtitle: "Based on Janeway's Immunobiology, 10th edition",
    author: "Zhao Wenying",
    date: "2026",
    accent: "red",
    status: "published",
    summary:
      "Cells of the immune system mostly emerge from the bone marrow while some mature elsewhere — for example, T cells mature in the thymus gland to undergo positive testing for MHC binding.",
    sections: [
      {
        heading: "Hematopoietic Stem Cells",
        blocks: [
          {
            type: "paragraph",
            text: "Cells of the immune system mostly emerge from the bone marrow while some may mature elsewhere. For example, T cells mature in the thymus gland to undergo positive testing for MHC binding. Some tissue-resident macrophages and lymphocytes originate from the yolk sac and fetal liver during embryonic development and are maintained throughout life as independent, self-renewing populations.",
          },
        ],
      },
      {
        heading: "Differentiation",
        blocks: [
          { type: "paragraph", text: "Below is a summarised step-by-step process by which differentiation occurs." },
          {
            type: "list",
            ordered: true,
            items: [
              {
                text: "Core Progenitor Branch",
                children: [
                  { text: "Long-term HSCs (LT-HSCs) — perpetual self-renewal in the bone marrow, fully quiescent except when triggered by injury." },
                  { text: "Short-term HSCs (ST-HSCs) — active stem cells with limited self-renewal capacity." },
                ],
              },
              {
                text: "Multipotent Progenitor (transition)",
                children: [
                  { text: "Immediate descendent of core stem cells, no ability to self-renew." },
                ],
              },
              {
                text: "Oligopotent Branches",
                children: [
                  {
                    text: "Common Myeloid Progenitor (CMP) — gives rise to all myeloid cells (red blood cells, platelets, and various infection-fighting white blood cells).",
                    children: [
                      { text: "Megakaryocyte/Erythrocyte Progenitor (MEP) — red blood cells, platelets." },
                      { text: "Granulocyte/Macrophage Progenitor (GMP) — Neutrophils, Eosinophils, Basophils, Monocytes." },
                    ],
                  },
                  {
                    text: "Common Lymphoid Progenitor (CLP) — gives rise to all lymphoid cells (T cells, B cells, Natural Killer cells, some dendritic cells).",
                    children: [
                      { text: "Forms both the adaptive and innate immune systems." },
                    ],
                  },
                ],
              },
              {
                text: "Terminal Differentiation",
                children: [
                  { text: "From CMP — Erythrocytes: red blood cells created via erythropoiesis for oxygen transport." },
                  { text: "From CMP — Megakaryocytes: large precursor cells that fragment to create platelets (thrombocytes) for blood clotting." },
                  { text: "From CMP — Granulocytes: innate white blood cells packed with microscopic granules (Neutrophils, Eosinophils, Basophils)." },
                  { text: "From CMP — Monocytes/Macrophages: large frontline immune cells specialised in engulfing pathogens." },
                  { text: "From CLP — B cells: adaptive immune cells that produce targeted antibodies." },
                  { text: "From CLP — T cells: adaptive immune cells that coordinate defenses and destroy infected host cells." },
                  { text: "From CLP — NK cells: innate cytotoxic cells that rapidly target viruses and tumors." },
                ],
              },
              {
                text: "Regulatory factors (chemical messengers)",
                children: [
                  { text: "External Growth Factors (GF) and Interleukins (ILs) — general signaling proteins that trigger overall cell maturation, e.g. Erythropoietin, Thrombopoietin, IL-3, IL-6, IL-7." },
                  { text: "Microenvironmental Regulators." },
                ],
              },
            ],
          },
        ],
      },
    ],
  },
  {
    slug: "lines-of-barriers",
    title: "Lines of Barriers Against Pathogens",
    subtitle: "Based on Advanced Immunology Foundations",
    author: "Zhao Wenying",
    date: "June 17, 2026",
    accent: "red",
    status: "published",
    summary:
      "The human body adopts three primary strategies to handle infectious microbes: avoidance, resistance, and tolerance.",
    sections: [
      {
        heading: "Introduction to Host Defense Strategies",
        blocks: [
          {
            type: "paragraph",
            text: "The human body adopts three primary strategies to handle the threats posed by infectious microbes: avoidance, resistance, and tolerance. Avoidance mechanisms prevent exposure to microbes entirely, resistance aims to reduce or eliminate established pathogens via immune mediators, and tolerance enhances tissue capacity to withstand damage without directly attacking the microbe.",
          },
        ],
      },
      {
        heading: "Levels of Defense Against Pathogens",
        blocks: [
          {
            type: "paragraph",
            text: "Protection against pathogens relies on multiple sequential layers of defense. If the initial physical and chemical barriers are breached, cellular mechanisms of the innate and adaptive immune systems are progressively activated.",
          },
          {
            type: "list",
            ordered: true,
            items: [
              {
                text: "Anatomic and Physical Barriers (Avoidance Strategy)",
                children: [
                  { text: "Skin — forms a continuous, structural outer barrier protecting internal tissues." },
                  { text: "Mucosal Surfaces — line the respiratory, gastrointestinal, and urogenital tracts to entrap and sweep away potential invaders." },
                  { text: "The skin and mucosal surfaces act as the absolute first line of defense to prevent microbial entry." },
                ],
              },
              {
                text: "Chemical and Enzymatic Systems (Immediate Resistance)",
                children: [
                  { text: "Antimicrobial Proteins — function as natural antibiotics produced directly at mucosal surfaces to destroy microbial membranes or inhibit growth." },
                  { text: "Complement System — a network of around 30 different plasma proteins acting together in serum and interstitial tissues. It can target and lyse foreign organisms even without specific antibodies." },
                ],
              },
              {
                text: "Cellular and Adaptive Defenses (Induced Responses)",
                children: [
                  { text: "Innate Lymphoid and Myeloid Cells — coordinate rapid, cell-mediated defenses immediately near breached epithelia." },
                  { text: "Adaptive Immune System — slower-acting but highly specific defenses brought to bear if pathogens overcome all preceding innate barriers." },
                ],
              },
            ],
          },
        ],
      },
      {
        heading: "The Triad of Host Immunity Strategies",
        blocks: [
          {
            type: "paragraph",
            text: "Understanding how a host survives microbial threats requires distinguishing between how the body manages exposure, clearance, and tissue damage.",
          },
          {
            type: "list",
            items: [
              { text: "Avoidance — anatomic barriers and behavioral modifications." },
              { text: "Resistance — effector mechanisms / mediators designed to eliminate microbes." },
              { text: "Tolerance — capacity enhancement to resist pathogen-induced damage." },
              { text: "Immunological Tolerance — distinct from tissue tolerance; prevents self-reactive immune responses." },
              { text: "Effector Mechanisms — molecular and cellular actions suited to resist distinct pathogen categories." },
            ],
          },
          {
            type: "note",
            text: "When structural physical barriers fail, chemical components such as the complement cascade provide an immediate bridge between innate resistance and adaptive responses.",
          },
          {
            type: "table",
            headers: ["", "Anatomic/Chemical Barriers", "Induced Cellular Responses"],
            rows: [
              ["Speed of action", "Immediate, constitutive barrier", "Delayed (hours for innate, days for adaptive)"],
              ["Primary components", "Skin, mucosa, antimicrobial proteins, complement", "Myeloid cells, lymphoid cells, antibodies"],
              ["Mechanism of action", "Physical exclusion and chemical lysis/inhibition", "Phagocytosis, cytotoxicity, targeted memory responses"],
              ["Primary strategy", "Avoidance and immediate localized resistance", "Systemic resistance and clearance"],
            ],
          },
        ],
      },
      {
        heading: "More about the Complement System",
        blocks: [
          {
            type: "paragraph",
            text: "Discovered natively alongside antibodies, the complement system consists of roughly 30 distinct soluble plasma proteins. It operates as one of the most vital effector cascades within extracellular fluids, functioning natively in both innate and adaptive immunity to clear pathogens via direct lysis, opsonisation, or inflammation recruitment.",
          },
        ],
      },
    ],
  },
  {
    slug: "cell-mediated-immunity",
    title: "Cell-mediated Immunity",
    subtitle: "Coming soon",
    author: "Zhao Wenying",
    date: "In progress",
    accent: "red",
    status: "in-progress",
    summary: "We are currently working hard on this section and will be launching soon. Please stay tuned for updates!",
  },
  {
    slug: "myeloid-lineage",
    title: "The Myeloid Lineage",
    subtitle: "Coming soon",
    author: "Zhao Wenying",
    date: "In progress",
    accent: "red",
    status: "in-progress",
    summary: "We are currently working hard on this section and will be launching soon. Please stay tuned for updates!",
  },
  {
    slug: "lymphoid-lineage",
    title: "The Lymphoid Lineage",
    subtitle: "Coming soon",
    author: "Zhao Wenying",
    date: "In progress",
    accent: "red",
    status: "in-progress",
    summary: "We are currently working hard on this section and will be launching soon. Please stay tuned for updates!",
  },
]

export function getTopic(slug: string) {
  return topics.find((t) => t.slug === slug)
}
