import Link from 'next/link'
import { cn } from '@/lib/utils'

const accentStyles = {
  magenta: 'bg-magenta text-cream',
  grape: 'bg-grape text-cream',
  coral: 'bg-coral text-cream',
} as const

type DashboardTileProps = {
  href: string
  title: string
  hover: string
  accent: keyof typeof accentStyles
  wide?: boolean
  badge?: string
}

export function DashboardTile({ href, title, hover, accent, wide, badge }: DashboardTileProps) {
  const disabled = href === '#'
  const baseClass = cn(
    'group relative flex min-h-36 flex-col items-center justify-center overflow-hidden rounded-2xl p-6 text-center shadow-lg transition-all duration-200',
    !disabled && 'hover:-translate-y-1 hover:brightness-110 hover:shadow-xl',
    disabled && 'cursor-not-allowed opacity-70',
    accentStyles[accent],
    wide && 'sm:col-span-2',
  )

  if (disabled) {
    return (
      <div className={baseClass} aria-disabled="true">
        {badge && (
          <span className="absolute right-3 top-3 rounded-full bg-cream/20 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide">
            {badge}
          </span>
        )}
        <span className="text-xl font-bold leading-tight text-balance">{title}</span>
      </div>
    )
  }

  return (
    <Link
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={baseClass}
    >
      {badge && (
        <span className="absolute right-3 top-3 rounded-full bg-cream/20 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide">
          {badge}
        </span>
      )}
      <span className="text-xl font-bold leading-tight text-balance transition-opacity duration-200 group-hover:opacity-0">
        {title}
      </span>
      <span className="pointer-events-none absolute inset-0 flex items-center justify-center p-6 text-sm leading-relaxed opacity-0 transition-opacity duration-200 group-hover:opacity-100 text-pretty">
        {hover}
      </span>
    </Link>
  )
}
