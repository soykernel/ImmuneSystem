import type { Block, ListItem } from '@/lib/content'

function ListItems({ items, ordered }: { items: ListItem[]; ordered?: boolean }) {
  const ListTag = ordered ? 'ol' : 'ul'
  return (
    <ListTag
      className={
        ordered
          ? 'ml-5 list-decimal space-y-2 marker:font-semibold marker:text-coral'
          : 'ml-5 list-disc space-y-2 marker:text-coral'
      }
    >
      {items.map((item, i) => (
        <li key={i} className="leading-relaxed text-pretty">
          {item.text}
          {item.children && item.children.length > 0 && (
            <div className="mt-2">
              <ListItems items={item.children} />
            </div>
          )}
        </li>
      ))}
    </ListTag>
  )
}

function BlockView({ block }: { block: Block }) {
  switch (block.type) {
    case 'paragraph':
      return <p className="leading-relaxed text-cream/90 text-pretty">{block.text}</p>
    case 'heading':
      return <h3 className="mt-2 text-lg font-bold text-cream">{block.text}</h3>
    case 'list':
      return <ListItems items={block.items} ordered={block.ordered} />
    case 'note':
      return (
        <aside className="rounded-xl border-l-4 border-coral bg-card/60 p-4 text-sm italic leading-relaxed text-cream/80">
          {block.text}
        </aside>
      )
    case 'table':
      return (
        <div className="overflow-x-auto rounded-xl border border-cream/15">
          <table className="w-full border-collapse text-left text-sm">
            <thead>
              <tr className="bg-grape/40">
                {block.headers.map((h, i) => (
                  <th key={i} className="border-b border-cream/15 px-4 py-3 font-bold text-cream">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {block.rows.map((row, r) => (
                <tr key={r} className="odd:bg-card/40">
                  {row.map((cell, c) => (
                    <td
                      key={c}
                      className={
                        c === 0
                          ? 'border-b border-cream/10 px-4 py-3 font-semibold text-cream'
                          : 'border-b border-cream/10 px-4 py-3 text-cream/85'
                      }
                    >
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )
    default:
      return null
  }
}

export function ContentRenderer({ blocks }: { blocks: Block[] }) {
  return (
    <div className="space-y-4">
      {blocks.map((block, i) => (
        <BlockView key={i} block={block} />
      ))}
    </div>
  )
}
