import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export function BackLink() {
  return (
    <Link
      href="/"
      className="inline-flex items-center gap-2 text-sm font-semibold text-cream/80 transition-colors hover:text-cream"
    >
      <ArrowLeft className="size-4" aria-hidden="true" />
      Back to dashboard
    </Link>
  )
}
